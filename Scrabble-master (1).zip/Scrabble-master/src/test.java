public class test {
    public static void main(String[] args) {
        String s = "hello";
        s = s.replaceFirst("e","");
        System.out.println(s);
    }
}
